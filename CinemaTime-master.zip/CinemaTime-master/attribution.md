App Icon
* [Tickets by Ryan Dell from the Noun Project](https://thenounproject.com/search/?q=tickets&i=27553)

Source Code
[QRCode](https://github.com/aschuch/QRCode)
